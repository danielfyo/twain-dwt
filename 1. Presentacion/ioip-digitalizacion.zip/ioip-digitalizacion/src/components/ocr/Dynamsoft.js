import Dynamsoft from "dynamsoft-javascript-barcode";
Dynamsoft.BarcodeReader.engineResourcePath = "https://cdn.jsdelivr.net/npm/dynamsoft-javascript-barcode@7.3.0-v0/dist/";
Dynamsoft.BarcodeReader.productKeys = "t0140cQMAAE8LWxVAHxlESW7JnSwHi4Gr4r8Df5baQ3boMjBgBMs//zRwatGJL1nxpE28FANXQu6g5e+JrEeOe47+lYwiv8iO4Z3pu9BZTJhMHw0Mvb9eu7E/puvPXOr0WSu+KDZMGIuNhHkIb/aGOPNpmDAWGwnzJDIfRddowjBhLDaCe2NaWy3NPlCFrqA=";// "t0070QQAAAD31luWIE5pROif90xJ9IShjcA0HIIiYpQco6rlnpQjYJU/TcbmVnhFlO0uGsGioWPxt2sQF8oLOk8kwxmAJ8R8QAQ==";
Dynamsoft.BarcodeReader._bUseFullFeature = true;
export default Dynamsoft;
